#include <iostream>

using namespace std;

int main()
{
    int  k=0;
    int arRay[k],size,j,i;

    cout << "\nEnter Array Size: "<< endl;
	cin >> size;
	cout << "\nEnter Array elements: "<< endl;
	for (j = 0; j< size; j++){
	cin>>arRay[j];
	}
    cout << "\nThe array is: "<< endl;
    for (j = 0; j< size; j++){
		cout << arRay[j] << ", ";
	}

    cout<<""<<endl;
    cout << "\nMake a copy List"<<endl;
    cout<<"Enter Array size: " <<endl;
    cin>>k;
    cout<<"New Array: " <<endl;
    for (i=0; i<k; i++){
    cout << arRay[i] << ", " <<endl;
    }
    cout <<"\nThis is the Original List: " <<endl;
    for (j = 0; j< size; j++){
    cout << arRay[j] << ", ";
	}
	cout<<""<<endl;

    cout<<"\nThis is the Copied List: " <<endl;
    for (i=0; i<k; i++){
    cout << arRay[i] << ", " <<endl;
    }

    cout<<"\nNow, this is the merged: "<<endl;
    for (j = 0; j< size; j++){
    cout << arRay[j] << ", ";
	}
    for(i=0; i<k; i++){
     (arRay[i]=arRay[i] +5);
    cout << arRay[i] << ", ";

    }


    return 0;
}

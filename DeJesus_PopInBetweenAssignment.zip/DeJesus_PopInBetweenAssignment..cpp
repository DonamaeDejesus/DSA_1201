#include <iostream>
#define SIZE 10

using namespace std;

class STACK{
private:

int top;
public:
int num[SIZE];
STACK();
int push(int);
int pop(int);
int isEmpty();
int isFull();
void displayItems();

};

STACK :: STACK(){
top=-1;
}


int STACK::isEmpty(){
if(top==-1)
return 1;
else
return 0;
}

int STACK::isFull(){
if(top==(SIZE-1))
return 1;
else
return 0;
}

int STACK::push(int n){
if(isFull()){
return 0;
}
++top;
num[top]=n;
return n;

}

int STACK::pop(int n){
int temp;
if(isEmpty())
return 0;
temp=num[ n];
for (int i=n; i<top; i++){
    num[i]= num [i+1];
}
--top;
return temp;
}

void STACK::displayItems()
{ int i;
cout << "STACK is: ";
if(isEmpty()){

cout << "Empty";
}
for(i=(top); i>=0; i-- ){
cout << num[i] << " \n";

}

}

int main()
{


STACK stk;


int i,COne,CTwo,temp;

do{
cout << "0 - Exit." << endl;
cout << "1 - Push item. " << endl;
cout << "2 - Pop item." << endl;
cout << "3 - Display Items (Print STACK)." << endl;

cout << "\nEnter your choice: ";
cin >> COne;

switch(COne){
case 0:
break;

case 1:
cout << "Enter the item to insert: ";
cin >>i;
temp = stk.push(i);

if(temp==0)
cout << "STACK IS FULL." << endl;
else
cout << temp << " inserted." << endl;
break;
case 2:

cout << "\nAt which position you want to pop?...";
cin >> CTwo;
temp = stk.pop(CTwo);

if(temp==0)
cout << "STACK IS EMPTY." << endl;
else
cout <<temp << " is removed (popped)." << endl;
break;

case 3:
stk.displayItems();
break;

default:
cout << "An Invalid choice." << endl;

}

}while(COne!=0);


return 0;
}
